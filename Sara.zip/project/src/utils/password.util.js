const bcrypt = require('bcryptjs');

/**
 * Hash a password
 * @param {string} password - The password to hash
 * @returns {Promise<string>} - The hashed password
 */
const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

/**
 * Compare a password with a hash
 * @param {string} password - The password to compare
 * @param {string} hashedPassword - The hashed password
 * @returns {Promise<boolean>} - Whether the password matches
 */
const comparePassword = async (password, hashedPassword) => {
  return await bcrypt.compare(password, hashedPassword);
};

/**
 * Validate password strength
 * @param {string} password - The password to validate
 * @returns {boolean} - Whether the password is strong enough
 */
const isStrongPassword = (password) => {
  // At least 8 characters, 1 number, 1 special character
  const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
  return passwordRegex.test(password);
};

module.exports = {
  hashPassword,
  comparePassword,
  isStrongPassword
};