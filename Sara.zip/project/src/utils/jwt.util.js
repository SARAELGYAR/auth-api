const jwt = require('jsonwebtoken');
const config = require('../config');

/**
 * Generate a JWT token
 * @param {Object} payload - The data to encode in the token
 * @returns {string} - The JWT token
 */
const generateToken = (payload) => {
  return jwt.sign(
    payload,
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn }
  );
};

/**
 * Verify a JWT token
 * @param {string} token - The token to verify
 * @returns {Object|null} - The decoded token or null if invalid
 */
const verifyToken = (token) => {
  try {
    return jwt.verify(token, config.jwtSecret);
  } catch (error) {
    return null;
  }
};

module.exports = {
  generateToken,
  verifyToken
};