const { 
  findUserById, 
  updateUser 
} = require('../config/db');
const { hashPassword } = require('../utils/password.util');

/**
 * Get user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getProfile = (req, res) => {
  try {
    const userId = req.user.id;
    const user = findUserById(userId);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    // Return user without password
    const { password, ...userWithoutPassword } = user;
    
    res.status(200).json({
      success: true,
      data: { user: userWithoutPassword }
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
};

/**
 * Update user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { email, password } = req.body;
    const updateData = {};

    // Add email to update data if provided
    if (email) {
      updateData.email = email;
    }

    // Hash password and add to update data if provided
    if (password) {
      updateData.password = await hashPassword(password);
    }

    // Update user
    const updatedUser = updateUser(userId, updateData);
    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found or update failed.'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      data: { user: updatedUser }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
};

/**
 * Update user role (admin only)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const updateUserRole = (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    // Update user role
    const updatedUser = updateUser(id, { role });
    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found or update failed.'
      });
    }

    res.status(200).json({
      success: true,
      message: 'User role updated successfully.',
      data: { user: updatedUser }
    });
  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
};

module.exports = {
  getProfile,
  updateProfile,
  updateUserRole
};