const express = require('express');
const userController = require('../controllers/user.controller');
const { 
  authenticateToken, 
  isAdmin 
} = require('../middleware/auth.middleware');
const { 
  validateProfileUpdate,
  validateRoleUpdate 
} = require('../middleware/validator.middleware');

const router = express.Router();

// Get user profile
router.get('/profile', authenticateToken, userController.getProfile);

// Update user profile
router.put('/profile', authenticateToken, validateProfileUpdate, userController.updateProfile);

// Update user role (admin only)
router.put('/users/:id/role', authenticateToken, isAdmin, validateRoleUpdate, userController.updateUserRole);

// Protected routes
router.get('/protected', authenticateToken, (req, res) => {
  res.status(200).json({
    success: true,
    message: 'This is a protected route.',
    data: { user: req.user }
  });
});

// Moderator route
router.get('/moderator', authenticateToken, (req, res) => {
  if (req.user.role === 'moderator' || req.user.role === 'admin') {
    return res.status(200).json({
      success: true,
      message: 'Welcome to the moderator area.',
      data: { user: req.user }
    });
  }
  
  res.status(403).json({
    success: false,
    message: 'Access denied. Insufficient permissions.'
  });
});

// Admin route
router.get('/admin', authenticateToken, (req, res) => {
  if (req.user.role === 'admin') {
    return res.status(200).json({
      success: true,
      message: 'Welcome to the admin area.',
      data: { user: req.user }
    });
  }
  
  res.status(403).json({
    success: false,
    message: 'Access denied. Insufficient permissions.'
  });
});

module.exports = router;