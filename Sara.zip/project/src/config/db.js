const fs = require('fs');
const path = require('path');

// Path to the database file
const dbPath = path.join(__dirname, '../../data');
const userDbPath = path.join(dbPath, 'users.json');

// Initialize the database
const initializeDb = () => {
  // Create the data directory if it doesn't exist
  if (!fs.existsSync(dbPath)) {
    fs.mkdirSync(dbPath, { recursive: true });
  }

  // Create the users.json file if it doesn't exist
  if (!fs.existsSync(userDbPath)) {
    fs.writeFileSync(userDbPath, JSON.stringify({ users: [] }));
  }
};

// Get all users
const getUsers = () => {
  try {
    const data = fs.readFileSync(userDbPath, 'utf8');
    return JSON.parse(data).users;
  } catch (error) {
    console.error('Error reading users:', error);
    return [];
  }
};

// Save users
const saveUsers = (users) => {
  try {
    fs.writeFileSync(userDbPath, JSON.stringify({ users }, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving users:', error);
    return false;
  }
};

// Find user by id
const findUserById = (id) => {
  const users = getUsers();
  return users.find(user => user.id === id);
};

// Find user by username
const findUserByUsername = (username) => {
  const users = getUsers();
  return users.find(user => user.username === username);
};

// Find user by email
const findUserByEmail = (email) => {
  const users = getUsers();
  return users.find(user => user.email === email);
};

// Create a new user
const createUser = (userData) => {
  const users = getUsers();
  const newUser = {
    id: Date.now().toString(),
    ...userData,
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  
  if (saveUsers(users)) {
    // Return user without password
    const { password, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  }
  return null;
};

// Update user
const updateUser = (id, userData) => {
  let users = getUsers();
  const userIndex = users.findIndex(user => user.id === id);
  
  if (userIndex !== -1) {
    users[userIndex] = {
      ...users[userIndex],
      ...userData,
      updatedAt: new Date().toISOString()
    };
    
    if (saveUsers(users)) {
      // Return user without password
      const { password, ...userWithoutPassword } = users[userIndex];
      return userWithoutPassword;
    }
  }
  return null;
};

module.exports = {
  initializeDb,
  getUsers,
  findUserById,
  findUserByUsername,
  findUserByEmail,
  createUser,
  updateUser
};