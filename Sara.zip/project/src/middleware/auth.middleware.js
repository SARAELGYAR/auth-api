const { verifyToken } = require('../utils/jwt.util');
const config = require('../config');

/**
 * Middleware to authenticate JWT token
 */
const authenticateToken = (req, res, next) => {
  // Get the authorization header
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. No token provided.'
    });
  }

  const decodedToken = verifyToken(token);
  if (!decodedToken) {
    return res.status(403).json({
      success: false,
      message: 'Invalid or expired token.'
    });
  }

  req.user = decodedToken;
  next();
};

/**
 * Middleware to check if user has the required role
 * @param {string[]} roles - The roles allowed to access the route
 */
const authorize = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated.'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. Insufficient permissions.'
      });
    }

    next();
  };
};

/**
 * Middleware for user role
 */
const isUser = (req, res, next) => {
  authorize([config.roles.USER, config.roles.MODERATOR, config.roles.ADMIN])(req, res, next);
};

/**
 * Middleware for moderator role
 */
const isModerator = (req, res, next) => {
  authorize([config.roles.MODERATOR, config.roles.ADMIN])(req, res, next);
};

/**
 * Middleware for admin role
 */
const isAdmin = (req, res, next) => {
  authorize([config.roles.ADMIN])(req, res, next);
};

module.exports = {
  authenticateToken,
  authorize,
  isUser,
  isModerator,
  isAdmin
};